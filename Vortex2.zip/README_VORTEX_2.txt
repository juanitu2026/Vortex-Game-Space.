# VorteX Game Space 2.0 — projeto-fonte

Este projeto parte do código Java original enviado e adiciona o painel flutuante VorteX.

## O que foi adicionado
- Item "Painel flutuante VorteX" na tela inicial.
- Solicitação da permissão Android "Aparecer sobre outros apps".
- Serviço em primeiro plano para manter o overlay ativo.
- Alça fina na borda direita; arrastar a alça revela o botão com a classe LogoView original (VX).
- Toque no botão abre a Central de Desempenho.
- Perfis visuais ECO, EQUILIBRADO e SUPER.
- Indicadores de RAM do sistema, bateria e temperatura da bateria.
- Recolher fecha o painel e retorna à linha. Pressionar e segurar o botão VX também recolhe.

## Limitações honestas
Os perfis, nesta primeira implementação, são seletores de perfil da interface. Um app Android comum sem APIs privilegiadas do fabricante/root não pode ajustar diretamente clocks de CPU/GPU nem garantir liberação de RAM. A RAM mostrada é o uso global aproximado do sistema, não RAM exclusiva do jogo. CPU/GPU/FPS ainda não estão conectados a uma fonte confiável e compatível com todos os aparelhos.

## Como abrir
Abra a pasta do projeto no Android Studio e sincronize com Gradle. O projeto usa Java 17, compileSdk 34 e targetSdk 34. Instale no aparelho, abra VorteX, toque em "Painel flutuante VorteX" e conceda a permissão de sobreposição. Depois toque novamente no item para iniciar o serviço.

## Observações
- O Android pode interromper serviços conforme configurações de bateria do fabricante.
- O serviço exibe uma notificação persistente enquanto o painel estiver ativo.
- Este ZIP contém o código-fonte. Não é um APK compilado.
