package com.vortex.gamespace;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int ACC = 0xFFFF2A45;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private FrameLayout root;
    private GridLayout grid;
    private TextView stBat, stTemp, stRam;
    private SharedPreferences prefs;
    private PackageManager pm;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean dndActive = false;

    static class Game {
        String pkg, label; Drawable icon;
        Game(String p, String l, Drawable i) { pkg = p; label = l; icon = i; }
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable shape(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("vx", MODE_PRIVATE);
        pm = getPackageManager();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF07070B);
        setContentView(root);
        buildHome();
        showSplash();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (dndActive) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm.isNotificationPolicyAccessGranted())
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
            dndActive = false;
        }
        refreshGames();
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() { updateStats(); handler.postDelayed(this, 2000); }
    };

    private void updateStats() {
        Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bi != null) {
            int level = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10;
            stBat.setText(level * 100 / scale + "%");
            stTemp.setText(temp + "°");
        }
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        stRam.setText((int) (100 - (mi.availMem * 100 / mi.totalMem)) + "%");
    }

    private void buildHome() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0B0B12, 0xFF180A12}));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(14), dp(16), dp(40));
        sv.addView(col);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(new LogoView(this), new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout tt = new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.setPadding(dp(12), 0, 0, 0);
        TextView h1 = text("VORTEX", 20, Color.WHITE, true); h1.setLetterSpacing(0.14f);
        TextView h2 = text("GAME SPACE", 10, ACC, true); h2.setLetterSpacing(0.3f);
        tt.addView(h1); tt.addView(h2);
        head.addView(tt);
        col.addView(head);

        LinearLayout row = new LinearLayout(this);
        stBat = stat(row, "BATERIA"); stTemp = stat(row, "TEMP"); stRam = stat(row, "RAM");
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rp.topMargin = dp(18); rp.bottomMargin = dp(22);
        col.addView(row, rp);

        col.addView(section("MEUS JOGOS"));
        grid = new GridLayout(this);
        grid.setColumnCount(3);
        col.addView(grid);

        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(WRAP, WRAP);
        sp.topMargin = dp(26);
        col.addView(section("PAINEL DE JOGO"), sp);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(shape(0xFF12121A, 20, 0x1AFFFFFF));

        Switch sw = new Switch(this);
        panel.addView(panelRow("Não perturbe no jogo", "Silencia avisos enquanto você joga", sw, null));
        sw.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{0xFFFFFFFF, 0xFFBBBBCC}));
        sw.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{ACC, 0xFF3A3A48}));
        NotificationManager nm0 = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        sw.setChecked(prefs.getBoolean("dnd", false) && nm0.isNotificationPolicyAccessGranted());
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (on && !nm.isNotificationPolicyAccessGranted()) {
                    v.setChecked(false);
                    toast("Permita o acesso ao Não perturbe para o VorteX");
                    openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                    return;
                }
                prefs.edit().putBoolean("dnd", on).apply();
            }
        });
        panel.addView(panelRow("Tela e brilho", "Abrir ajustes da tela", null, Settings.ACTION_DISPLAY_SETTINGS));
        panel.addView(panelRow("Economia de bateria", "Abrir ajustes de bateria", null, Settings.ACTION_BATTERY_SAVER_SETTINGS));
        panel.addView(panelRow("Painel flutuante VorteX", "Linha lateral e central de desempenho", null, "VORTEX_OVERLAY"));
        col.addView(panel);

        root.addView(sv, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private TextView section(String s) {
        TextView t = text(s, 12, 0xFF8B8B9A, true);
        t.setLetterSpacing(0.25f);
        t.setPadding(dp(2), 0, 0, dp(12));
        return t;
    }

    private TextView stat(LinearLayout row, String label) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(12), dp(12), dp(12));
        c.setBackground(shape(0xFF12121A, 16, 0x1AFFFFFF));
        TextView v = text("--", 20, Color.WHITE, true);
        TextView l = text(label, 11, 0xFF8B8B9A, false);
        l.setLetterSpacing(0.12f);
        c.addView(v); c.addView(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp.leftMargin = dp(5); lp.rightMargin = dp(5);
        row.addView(c, lp);
        return v;
    }

    private View panelRow(String title, String sub, Switch sw, final String settingsAction) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(text(title, 15, Color.WHITE, false));
        tx.addView(text(sub, 12, 0xFF8B8B9A, false));
        r.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
        if (sw != null) {
            r.addView(sw);
        } else {
            r.addView(text("›", 22, 0xFF8B8B9A, false));
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openSettings(settingsAction); }
            });
        }
        return r;
    }

    private void openSettings(String action) {
        try {
            if ("VORTEX_OVERLAY".equals(action)) {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                    Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                    startActivity(permission);
                    toast("Autorize 'Aparecer sobre outros apps' e toque novamente.");
                    return;
                }
                Intent service = new Intent(this, VortexOverlayService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
                toast("Painel flutuante VorteX ativado");
                return;
            }
            startActivity(new Intent(action));
        } catch (Exception e) { toast("Não foi possível abrir"); }
    }

    // ---------- Jogos ----------
    private List<Game> allApps() {
        List<Game> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            String pkg = ri.activityInfo.applicationInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            out.add(new Game(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)));
        }
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }

    private List<Game> findGames() {
        Set<String> added = new HashSet<>(prefs.getStringSet("added", new HashSet<String>()));
        Set<String> hidden = new HashSet<>(prefs.getStringSet("hidden", new HashSet<String>()));
        List<Game> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            ApplicationInfo ai = ri.activityInfo.applicationInfo;
            String pkg = ai.packageName;
            if (pkg.equals(getPackageName()) || hidden.contains(pkg) || !seen.add(pkg)) continue;
            boolean game = added.contains(pkg);
            if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) game = true;
            if ((ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0) game = true;
            if (game) out.add(new Game(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)));
        }
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }

    private void refreshGames() {
        grid.removeAllViews();
        int w = (getResources().getDisplayMetrics().widthPixels - dp(32)) / 3;
        for (final Game g : findGames()) {
            addCell(w, g.icon, g.label, new View.OnClickListener() {
                @Override public void onClick(View v) { launchGame(g); }
            });
        }
        addCell(w, null, "Editar lista", new View.OnClickListener() {
            @Override public void onClick(View v) { editList(); }
        });
    }

    private void addCell(int w, Drawable icon, String label, View.OnClickListener click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(dp(6), dp(8), dp(6), dp(8));
        View tile;
        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(icon);
            iv.setClipToOutline(true);
            iv.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(16)); }
            });
            tile = iv;
        } else {
            TextView p = text("+", 30, 0xFF8B8B9A, false);
            p.setGravity(Gravity.CENTER);
            p.setBackground(shape(0x00000000, 16, 0x55FFFFFF));
            tile = p;
        }
        c.addView(tile, new LinearLayout.LayoutParams(dp(64), dp(64)));
        TextView n = text(label, 12, 0xFFD6D6E0, false);
        n.setGravity(Gravity.CENTER);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(MATCH, WRAP);
        np.topMargin = dp(6);
        c.addView(n, np);
        c.setOnClickListener(click);
        c.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80);
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(120);
                return false;
            }
        });
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = w;
        gp.height = WRAP;
        grid.addView(c, gp);
    }

    private void editList() {
        final List<Game> all = allApps();
        final Set<String> cur = new HashSet<>();
        for (Game g : findGames()) cur.add(g.pkg);
        String[] names = new String[all.size()];
        final boolean[] checked = new boolean[all.size()];
        for (int k = 0; k < all.size(); k++) {
            names[k] = all.get(k).label;
            checked[k] = cur.contains(all.get(k).pkg);
        }
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Escolha seus jogos")
            .setMultiChoiceItems(names, checked, (d, which, isChecked) -> checked[which] = isChecked)
            .setPositiveButton("Salvar", (d, which) -> {
                Set<String> added = new HashSet<>(prefs.getStringSet("added", new HashSet<String>()));
                Set<String> hidden = new HashSet<>(prefs.getStringSet("hidden", new HashSet<String>()));
                for (int k = 0; k < all.size(); k++) {
                    String p = all.get(k).pkg;
                    if (checked[k]) { added.add(p); hidden.remove(p); }
                    else if (cur.contains(p)) { added.remove(p); hidden.add(p); }
                    else { added.remove(p); }
                }
                prefs.edit().putStringSet("added", added).putStringSet("hidden", hidden).apply();
                refreshGames();
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void launchGame(final Game g) {
        final Intent li = pm.getLaunchIntentForPackage(g.pkg);
        if (li == null) { toast("Não consegui abrir " + g.label); return; }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (prefs.getBoolean("dnd", false)) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm.isNotificationPolicyAccessGranted()) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
                dndActive = true;
            }
        }
        final FrameLayout ov = new FrameLayout(this);
        ov.setBackgroundColor(Color.BLACK);
        ov.setClickable(true);
        LinearLayout lay = new LinearLayout(this);
        lay.setOrientation(LinearLayout.VERTICAL);
        lay.setGravity(Gravity.CENTER);
        lay.addView(new LogoView(this), new LinearLayout.LayoutParams(dp(110), dp(110)));
        TextView t = text("ABRINDO " + g.label.toUpperCase(), 14, Color.WHITE, true);
        t.setLetterSpacing(0.2f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(24), dp(16), dp(18));
        lay.addView(t);
        final ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setProgressTintList(ColorStateList.valueOf(ACC));
        lay.addView(pb, new LinearLayout.LayoutParams(dp(200), dp(4)));
        ov.addView(lay, new FrameLayout.LayoutParams(MATCH, MATCH));
        ov.setAlpha(0f);
        root.addView(ov, new FrameLayout.LayoutParams(MATCH, MATCH));
        ov.animate().alpha(1f).setDuration(200);
        ValueAnimator va = ValueAnimator.ofInt(0, 100);
        va.setDuration(1300);
        va.addUpdateListener(a -> pb.setProgress((Integer) a.getAnimatedValue()));
        va.start();
        handler.postDelayed(() -> {
            try { startActivity(li); } catch (Exception e) { toast("Não consegui abrir " + g.label); }
            root.removeView(ov);
        }, 1400);
    }

    // ---------- Abertura animada ----------
    private void showSplash() {
        final FrameLayout sp = new FrameLayout(this);
        sp.setBackgroundColor(Color.BLACK);
        sp.setClickable(true);
        final LogoView lv = new LogoView(this);
        lv.setProgress(0f);
        sp.addView(lv, new FrameLayout.LayoutParams(dp(220), dp(220), Gravity.CENTER));
        final TextView name = text("VorteX", 44, Color.WHITE, true);
        name.setLetterSpacing(0.08f);
        name.setAlpha(0f);
        sp.addView(name, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
        root.addView(sp, new FrameLayout.LayoutParams(MATCH, MATCH));

        ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(900);
        anim.setStartDelay(150);
        anim.setInterpolator(new DecelerateInterpolator(2f));
        anim.addUpdateListener(a -> lv.setProgress((Float) a.getAnimatedValue()));
        anim.start();

        final Runnable finish = () -> {
            if (sp.getParent() == null) return;
            sp.animate().alpha(0f).setDuration(400).withEndAction(() -> root.removeView(sp));
        };
        handler.postDelayed(() -> {
            lv.animate().alpha(0f).scaleX(0.55f).scaleY(0.55f).setDuration(600);
            name.setScaleX(0.8f); name.setScaleY(0.8f);
            name.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700);
        }, 2100);
        handler.postDelayed(finish, 4200);
        sp.setOnClickListener(v -> finish.run());
    }
}
