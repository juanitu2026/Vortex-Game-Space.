package com.vortex.gamespace;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/** Logo VorteX: um V em cima e um V invertido embaixo formam o X. */
public class LogoView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress = 1f;

    public LogoView(Context c) {
        super(c);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(78f);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    public void setProgress(float v) { progress = v; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight()) / 512f;
        float ox = (getWidth() - 512f * s) / 2f;
        float oy = (getHeight() - 512f * s) / 2f;
        float off = (1f - progress) * 110f;
        p.setAlpha((int) (255 * Math.min(1f, progress * 1.4f)));
        half(c, s, ox, oy, -off, 58f, 247f);
        half(c, s, ox, oy, off, 269f, 458f);
    }

    private void half(Canvas c, float s, float ox, float oy, float dy, float top, float bottom) {
        c.save();
        c.translate(ox, oy + dy * s);
        c.scale(s, s);
        c.clipRect(0f, top, 512f, bottom);
        c.drawLine(25.6f, -58.8f, 486.4f, 574.8f, p);
        c.drawLine(486.4f, -58.8f, 25.6f, 574.8f, p);
        c.restore();
    }
}
