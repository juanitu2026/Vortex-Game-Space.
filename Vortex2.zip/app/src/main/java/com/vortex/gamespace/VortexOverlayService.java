package com.vortex.gamespace;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/**
 * Painel flutuante VorteX. A alça recolhida vira uma linha na borda;
 * arrastar para dentro revela o botão VX; tocar nele abre a central.
 */
public class VortexOverlayService extends Service {
    private WindowManager wm;
    private View handle;
    private View button;
    private View panel;
    private WindowManager.LayoutParams handleParams;
    private boolean expanded = false;
    private String mode = "EQUILIBRADO";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView ramValue, batteryValue, tempValue, modeValue;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        startAsForeground();
        createHandle();
        handler.post(stats);
    }

    private void startAsForeground() {
        String channel = "vortex_overlay";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(channel, "VorteX Game Assistant",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(nc);
        }
        Notification n;
        if (Build.VERSION.SDK_INT >= 26) {
            n = new Notification.Builder(this, channel)
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentTitle("VorteX Game Assistant")
                    .setContentText("Painel flutuante ativo")
                    .setOngoing(true).build();
        } else {
            n = new Notification.Builder(this)
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentTitle("VorteX Game Assistant")
                    .setContentText("Painel flutuante ativo")
                    .setOngoing(true).build();
        }
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(42, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(42, n);
    }

    private GradientDrawable bg(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(dp(radius)); d.setStroke(dp(1.5f), stroke); return d;
    }
    private WindowManager.LayoutParams params(int w, int h, int gravity) {
        return new WindowManager.LayoutParams(w, h, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT) {{ this.gravity = gravity; }};
    }

    private void createHandle() {
        FrameLayout touchArea = new FrameLayout(this);
        touchArea.setBackgroundColor(Color.TRANSPARENT);
        View line = new View(this);
        line.setBackground(bg(0xFF24112D, 0xFFE34275, 12));
        FrameLayout.LayoutParams lineLp = new FrameLayout.LayoutParams(dp(4), dp(66), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        touchArea.addView(line, lineLp);
        handle = touchArea;
        handleParams = params(dp(28), dp(82), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        wm.addView(handle, handleParams);
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY(); moved=false; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx=e.getRawX()-downX, dy=e.getRawY()-downY;
                    if (Math.abs(dx)>dp(12) || Math.abs(dy)>dp(12)) moved=true;
                    if (moved) {
                        handleParams.y += (int)dy;
                        handleParams.x = Math.max(0, (int)-Math.max(0, dx));
                        try { wm.updateViewLayout(handle, handleParams); } catch(Exception ignored) {}
                        downX=e.getRawX(); downY=e.getRawY();
                    }
                    return true;
                }
                if (e.getAction()==MotionEvent.ACTION_UP) {
                    if (moved) revealButton(); else revealButton();
                    return true;
                }
                return true;
            }
        });
    }

    private void revealButton() {
        if (handle != null) { try { wm.removeView(handle); } catch(Exception ignored) {} handle=null; }
        TextView vx = new TextView(this);
        vx.setText("V\nX");
        vx.setGravity(Gravity.CENTER);
        vx.setTextColor(Color.WHITE);
        vx.setTextSize(22);
        vx.setTypeface(Typeface.DEFAULT_BOLD);
        vx.setBackground(bg(0xFF09090E, 0xFFE34275, 18));
        button=vx;
        WindowManager.LayoutParams p=params(dp(62), dp(68), Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        wm.addView(button,p);
        button.setOnClickListener(v -> openPanel());
        button.setOnLongClickListener(v -> { collapse(); return true; });
        expanded=true;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void openPanel() {
        if (panel != null) { try { wm.removeView(panel); } catch(Exception ignored) {} }
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(14),dp(16),dp(14));
        box.setBackground(bg(0xF20A0A12,0xFFE34275,22));
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=label("V X",23,Color.WHITE,true);
        header.addView(logo,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView close=label("×",28,0xFFFF729B,true); close.setGravity(Gravity.CENTER);
        header.addView(close,new LinearLayout.LayoutParams(dp(40),dp(42)));
        box.addView(header);
        box.addView(label("VORTEX  /  CENTRAL DE DESEMPENHO",10,0xFFCC8BFF,true));
        modeValue=label("MODO: "+mode,15,Color.WHITE,true);
        LinearLayout modes=new LinearLayout(this); modes.setPadding(0,dp(12),0,dp(8));
        addMode(modes,"ECO"); addMode(modes,"EQUILIBRADO"); addMode(modes,"SUPER");
        box.addView(modes); box.addView(modeValue);
        ramValue=label("RAM: --",14,0xFFE8E8F2,false);
        batteryValue=label("BATERIA: --",14,0xFFE8E8F2,false);
        tempValue=label("TEMPERATURA: --",14,0xFFE8E8F2,false);
        box.addView(ramValue); box.addView(batteryValue); box.addView(tempValue);
        box.addView(label("CPU / GPU: métricas avançadas dependem do Android/fabricante",10,0xFFB7A8C5,false));
        TextView collapse=label("RECOLHER",12,0xFFFF729B,true);
        collapse.setGravity(Gravity.CENTER); collapse.setPadding(0,dp(12),0,dp(2));
        box.addView(collapse);
        close.setOnClickListener(v -> closePanel());
        collapse.setOnClickListener(v -> closePanel());
        panel=box;
        WindowManager.LayoutParams p=params(dp(300),WindowManager.LayoutParams.WRAP_CONTENT,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        p.x=dp(12);
        wm.addView(panel,p);
        updateStats();
    }
    private void addMode(LinearLayout row, String name) {
        TextView b=label(name,10,Color.WHITE,true); b.setGravity(Gravity.CENTER);
        b.setPadding(dp(5),dp(10),dp(5),dp(10));
        b.setBackground(bg(name.equals(mode) ? 0xFF552044 : 0xFF191522,0xFFB34CFF,9));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);
        lp.setMargins(dp(2),0,dp(2),0); row.addView(b,lp);
        b.setOnClickListener(v -> {
            mode=name; modeValue.setText("MODO: "+mode);
            for(int i=0;i<row.getChildCount();i++) {
                TextView item=(TextView)row.getChildAt(i);
                String n=item.getText().toString();
                item.setBackground(bg(n.equals(mode)?0xFF552044:0xFF191522,0xFFB34CFF,9));
            }
        });
    }
    private void updateStats() {
        try {
            ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
            int used=(int)((mi.totalMem-mi.availMem)*100/Math.max(1,mi.totalMem));
            Intent bi=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi!=null) {
                int level=bi.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
                int scale=bi.getIntExtra(BatteryManager.EXTRA_SCALE,100);
                int temp=bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0);
                if(ramValue!=null) ramValue.setText("RAM do sistema em uso: "+used+"%");
                if(batteryValue!=null) batteryValue.setText("BATERIA: "+(level*100/Math.max(1,scale))+"%");
                if(tempValue!=null) tempValue.setText(String.format(Locale.getDefault(),"TEMPERATURA DA BATERIA: %.1f °C",temp/10f));
            }
        } catch(Exception ignored) {}
    }
    private final Runnable stats=new Runnable() {
        @Override public void run() { updateStats(); handler.postDelayed(this,2500); }
    };
    private void closePanel() {
        if(panel!=null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel=null; }
        collapse();
    }
    private void collapse() {
        if(panel!=null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel=null; }
        if(button!=null) { try { wm.removeView(button); } catch(Exception ignored) {} button=null; }
        expanded=false; createHandle();
    }
    @Override public int onStartCommand(Intent i,int flags,int id) { return START_STICKY; }
    @Override public void onDestroy() {
        handler.removeCallbacks(stats);
        for(View v:new View[]{panel,button,handle}) if(v!=null) try { wm.removeView(v); } catch(Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
